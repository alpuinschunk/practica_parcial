#ifndef NEGOCIO_H_INCLUDED
#define NEGOCIO_H_INCLUDED








//Hay que crear un 5to struct de sectores

int inicializarEmpleados(eEmpleados* lista, int tam);


#endif
