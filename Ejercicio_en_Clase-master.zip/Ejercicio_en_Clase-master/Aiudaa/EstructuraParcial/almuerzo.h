#ifndef ALMUERZO_H_INCLUDED
#define ALMUERZO_H_INCLUDED

typedef struct
{
   int id; //autoincremental
   int idComida; //Debe existir
   int lejagoEmpleado; //debe existir
   eFecha fechaAlmuerzo;
  // int isEmpty;
}eAlmuerzo;

#endif
