#ifndef SECTOR_H_INCLUDED
#define SECTOR_H_INCLUDED

typedef struct //hardcodear lista de sectores
{
    int id;
    char descripcion[51];

}eSector;

#endif
